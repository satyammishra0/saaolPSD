// document.addEventListener("DOMContentLoaded", function () {
//   new Glider(document.querySelector(".glider"), {
//     slidesToShow: 1,
//     slidesToScroll: 1,
//     draggable: true,
//     dots: "",
//     arrows: {
//       prev: ".glider-prev",
//       next: ".glider-next",
//     },
//     responsive: [
//       {
//         breakpoint: 800,
//         settings: {
//           slidesToShow: 1,
//           slidesToScroll: 1,
//         },
//       },
//       {
//         breakpoint: 600,
//         settings: {
//           slidesToShow: 1,
//           slidesToScroll: 1,
//         },
//       },
//     ],
//   });
// });
